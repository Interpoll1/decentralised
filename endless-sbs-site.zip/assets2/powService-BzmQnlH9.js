import{C as h}from"./vendor-signal-BEcdMOVt.js";import{W as c}from"./index-BYckQyOE.js";import{V as d,U as w}from"./userService-B7jNbF1M.js";import"./vendor-misc-D4iucfk1.js";import"./vendor-ionic-CVBelytc.js";import"./vendor-vue-B2Vdc9yd.js";import"./vendor-crypto-B3FUjrGe.js";import"./vendor-ionicons-D2nD6DnL.js";const g=new Set(["broadcast","new-poll","new-block"]),p=1e4,m=5e3,u=24,y=128,b=5e3,v=16,a=3e4;function I(o){let t=0;for(const e of o){const n=parseInt(e,16);if(n===0)t+=4;else{n<2?t+=3:n<4?t+=2:n<8&&(t+=1);break}}return t}function E(o){if(typeof o.challengeId!="string"||o.challengeId.length===0)throw new Error("PoW challenge missing challengeId");if(typeof o.prefix!="string"||o.prefix.length===0)throw new Error("PoW challenge missing prefix");if(!Number.isFinite(o.difficulty)||o.difficulty<1)throw new Error(`PoW difficulty invalid: ${o.difficulty}`);if(o.difficulty>u)throw new Error(`PoW difficulty ${o.difficulty} exceeds client maximum ${u}`);if(o.prefix.length>y)throw new Error("PoW challenge prefix too long");if(o.expiresAt<Date.now()+b)throw new Error("PoW challenge TTL too short or already expired")}const x=`
self.onmessage = async function(e) {
  const { prefix, challengeId, difficulty } = e.data;
  let nonce = 0;
  const BATCH = 10000;
  function zeros(hex) {
    let b = 0;
    for (const ch of hex) {
      const n = parseInt(ch, 16);
      if (n === 0) { b += 4; continue; }
      if (n < 2) b += 3; else if (n < 4) b += 2; else if (n < 8) b += 1;
      break;
    }
    return b;
  }
  async function sha256(str) {
    const buf = new TextEncoder().encode(str);
    const h = await crypto.subtle.digest('SHA-256', buf);
    return Array.from(new Uint8Array(h)).map(b=>b.toString(16).padStart(2,'0')).join('');
  }
  while (nonce < 2**32) {
    for (let i = 0; i < BATCH && nonce < 2**32; i++, nonce++) {
      const hash = await sha256(prefix + nonce);
      if (zeros(hash) >= difficulty) {
        self.postMessage({ ok: true, nonce, hash, challengeId });
        return;
      }
    }
  }
  self.postMessage({ ok: false, error: 'Exhausted nonce space' });
};
`;function S(o){return new Promise((t,e)=>{const n=new Blob([x],{type:"application/javascript"}),i=URL.createObjectURL(n),s=new Worker(i);s.onmessage=r=>{URL.revokeObjectURL(i),s.terminate(),r.data.ok?t(r.data.nonce):e(new Error(r.data.error))},s.onerror=r=>{URL.revokeObjectURL(i),s.terminate(),e(new Error(r.message))},s.postMessage({prefix:o.prefix,challengeId:o.challengeId,difficulty:o.difficulty})})}class _{static challengeResolver=null;static initialized=!1;static proofQueue=Promise.resolve();static initialize(){this.initialized||(this.initialized=!0,c.subscribe("pow-required",t=>{const e=t?.reason??"unknown reason";console.warn("[PoW] Server requires proof-of-work:",e)}),c.subscribe("pow-challenge",t=>{if(this.challengeResolver){const e=t,n={challengeId:e.challengeId,prefix:e.prefix,difficulty:e.difficulty,expiresAt:e.expiresAt},i=this.challengeResolver;this.challengeResolver=null,i.resolve(n)}}))}static async requestServerChallenge(t){this.initialize();const e=await d.getDeviceId();let n="";try{const i=await w.getCurrentUser();n=(i.identityUsername||i.customUsername||i.username||"").trim()}catch(i){console.warn("[PoW] Proceeding without identity username claim:",i)}return new Promise((i,s)=>{const r=setTimeout(()=>{this.challengeResolver=null,s(new Error("PoW challenge request timed out"))},p);this.challengeResolver={resolve:f=>{clearTimeout(r),i(f)},reject:f=>{clearTimeout(r),s(f)}},c.sendRaw({type:"request-pow",deviceId:e,action:t,identityUsername:n})||(this.challengeResolver=null,clearTimeout(r),s(new Error("WebSocket not connected")))})}static generateClientChallenge(t){const e=Math.floor(Date.now()/a)*a,n=h.hash(JSON.stringify({contentHash:t,windowTs:e}));return{challengeId:n,prefix:n.slice(0,32),difficulty:v,expiresAt:e+a}}static async solve(t){E(t);try{return await S(t)}catch{}const{prefix:e,difficulty:n,expiresAt:i}=t;let s=0;for(;;){if(Date.now()>i)throw new Error("PoW challenge expired during solving");for(let r=0;r<m;r++){const l=h.hash(e+s.toString());if(I(l)>=n)return s;s++}await new Promise(r=>setTimeout(r,0))}}static getProof(t,e){const n=async()=>{if(c.getConnectionStatus()){const r=await this.requestServerChallenge(t),l=await this.solve(r);return{challengeId:r.challengeId,nonce:l}}else{e||(e=h.hash(`${t}-${Math.floor(Date.now()/a)}`));const r=this.generateClientChallenge(e),l=await this.solve(r);return{challengeId:r.challengeId,nonce:l,clientGenerated:!0,contentHash:e,windowTs:Math.floor(Date.now()/a)*a}}},i=this.proofQueue.then(n,n);return this.proofQueue=i.then(()=>{},()=>{}),i}static requiresProof(t,e){return!(!g.has(t)||t==="new-block"&&e&&e!=="post-create")}}export{_ as PowService};
