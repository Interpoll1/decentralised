# Composables — `src/composables/`

> **Keep this file updated** whenever you add, remove, or change a composable.

Vue 3 composables that bridge stores/services with component logic.

## Inventory

| File | Export | Purpose |
|---|---|---|
| `useChainSync.ts` | `useChainSync()` | Polls `chainStore.chainHead` every 10 seconds and calls `checkForDowngrade()`. Returns `downgradeDetected` (ref), `lastSync` (ref), `resetDowngradeAlert()`. Mount in `App.vue` or a top-level layout component. |
| `useChat.ts` | `useChat()` | Manages a `ChatService` instance for the current user. Handles init, message sending, and a reactive per-peer message map. The instance is held in a **`shallowRef`** — a deep `ref` handed back a reactive Proxy whose private-field access has a different identity than `this`, which is why the declared `Ref<ChatService>` never type-checked. `sendMessage()` returns the stored `ChatMessage` and upserts it by id; it does **not** append an optimistic duplicate (that produced two bubbles per send). `loadHistory()` paints `getLocalHistory()` first, then merges the graph. Read receipts are a watermark: only messages with `timestamp <= at` are marked read. |
| `useFingerprint.ts` | `useFingerprint()` | Wraps `CryptoService.generateFingerprint()`. Returns `fingerprint` (ref), `isLoading` (ref), `generateFingerprint()`. |
| `useModerationFilter.ts` | `useModerationFilter()` | Exposes moderation settings and filter functions. Uses `ModerationService` + `userStore`. `shouldShow(item)` checks both karma and content score. `getContentAction(text)` returns `blur`/`hide`/`flag`/`show`. |
| `useFeedPreferences.ts` | `useFeedPreferences()` | Reactive wrapper for personalized feed settings. Exposes feed mode, keyword include/exclude management, muted/favorite community toggles, content-type visibility, ranking weights, and reset helpers via `FeedPreferencesService`. |
| `useSearch.ts` | `useSearch(apiUrl?)` | Wraps `SearchService` instance with reactive state (`results`, `loading`, `error`, pagination). If `apiUrl` is omitted, requests resolve through `config.relay.api` at call time so Search keeps following Settings/runtime relay overrides. Provides `search()`, `searchPosts()`, `searchPolls()`, `searchInCommunity()`, `nextPage()`, `previousPage()`. Deliberately exposes **no** `indexContent()` — indexing happens on the relay's Gun write path, not in the client (see `src/services/copilot-services.md`). |
| `useProofOfWork.ts` | `useProofOfWork()` | Wraps `PowService.getProof()` with reactive state for UI feedback. Returns `solving` (ref), `error` (ref), `getProof(action)`. Guards against concurrent calls. For transparent PoW (no UI), `WebSocketService.broadcast()` handles it automatically. |

## Conventions

- Composables call stores or services — not other composables.
- Always clean up subscriptions/intervals inside `onUnmounted` if the composable registers them.
