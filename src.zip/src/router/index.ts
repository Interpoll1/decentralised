import { createRouter, createWebHistory } from '@ionic/vue-router';
import { RouteRecordRaw } from 'vue-router';

const ONBOARDING_KEY = 'interpoll_onboarding_complete';

const routes: Array<RouteRecordRaw> = [
  {
    path: '/',
    redirect: () => {
      const done = localStorage.getItem(ONBOARDING_KEY) === 'true';
      return done ? '/home' : '/onboarding';
    },
  },
  {
    path: '/onboarding',
    name: 'Onboarding',
    component: () => import('../views/OnboardingPage.vue'),
  },
  { path: '/home', name: 'Home', component: () => import('../views/HomePage.vue') },
  // Shareable aliases for the HomePage tabs (tab state lives in the ?tab query)
  { path: '/communities', redirect: { path: '/home', query: { tab: 'communities' } } },
  { path: '/spaces',      redirect: { path: '/home', query: { tab: 'communities' } } },
  { path: '/chat',        redirect: { path: '/home', query: { tab: 'chat' } } },
  { path: '/create',      redirect: { path: '/home', query: { tab: 'create' } } },
  {
    path: '/community/:communityId',
    name: 'Community',
    component: () => import('../views/CommunityPage.vue'),
    props: route => ({ communityId: route.params.communityId })
  },
  {
    path: '/community/:communityId/create-post',
    name: 'CreatePost',
    component: () => import('../views/CreatePostPage.vue'),
    props: true
  },
  {
    path: '/community/:communityId/poll/:pollId',
    name: 'PollDetail',
    component: () => import('../views/PollDetailPage.vue'),
    props: true
  },
  {
    // Standalone poll route — polls without a communityId are navigated here.
    // navigateToPoll() in HomePage falls back to /poll/:id when communityId is absent,
    // and direct URL sharing of community-less polls also lands here.
    path: '/poll/:pollId',
    name: 'PollDetailStandalone',
    component: () => import('../views/PollDetailPage.vue'),
    props: true
  },
  { path: '/post/:postId', name: 'PostDetail', component: () => import('../views/PostDetailPage.vue'), props: true },
  { path: '/create-community', name: 'CreateCommunity', component: () => import('../views/CreateCommunityPage.vue') },
  { path: '/create-poll', name: 'CreatePoll', component: () => import('../views/CreatePollPage.vue') },
  {
    path: '/community/:communityId/create-poll',
    name: 'CreatePollInCommunity',
    component: () => import('../views/CreatePollPage.vue'),
    props: route => ({ communityId: route.params.communityId }),
  },
  { path: '/profile', name: 'Profile', component: () => import('../views/ProfilePage.vue') },
  { path: '/user/:userId', name: 'UserProfile', component: () => import('../views/UserProfileView.vue'), props: true },
  { path: '/settings', name: 'Settings', component: () => import('../views/SettingsPage.vue') },
  // ── NEW: promoted Network page ───────────────────────────────────────────────
  { path: '/network', name: 'Network', component: () => import('../views/NetworkPage.vue') },
  { path: '/chain-explorer', name: 'ChainExplorer', component: () => import('../views/ChainExplorerPage.vue') },
  { path: '/vote/:pollId', name: 'Vote', component: () => import('../views/VotePage.vue'), props: true },
  { path: '/results/:pollId', name: 'Results', component: () => import('../views/ResultsPage.vue'), props: true },
  { path: '/receipt/:verificationCode?', name: 'Receipt', component: () => import('../views/ReceiptPage.vue') },
  { path: '/search', name: 'Search', component: () => import('../views/SearchView.vue') },
  { path: '/chat/:userId', name: 'Chat', component: () => import('../views/ChatView.vue'), props: true },
  { path: '/resilience', name: 'Resilience', component: () => import('../views/ResiliencePage.vue') },
  { path: '/chatroom/:roomId', name: 'ChatRoom', component: () => import('../views/ChatRoomPage.vue'), props: true },
  { path: '/chatrooms', name: 'ChatRoomList', component: () => import('../views/ChatRoomListPage.vue') },
  { path: '/join/:type/:id', name: 'JoinPrivate', component: () => import('../views/JoinPrivatePage.vue') },
  {
    path: '/claim-username',
    name: 'ClaimUsername',
    component: () => import('../views/ClaimUsernamePage.vue')
  },
  { path: '/auth/callback', name: 'AuthCallback', component: () => import('../views/AuthCallbackPage.vue') },
  // Catch-all
  { path: '/:pathMatch(.*)*', redirect: '/home' }
];

const router = createRouter({
  history: createWebHistory('/'),
  routes
});

export default router;
