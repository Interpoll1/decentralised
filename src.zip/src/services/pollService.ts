import { GunService, GUN_NAMESPACE } from './gunService';
import { EncryptionService } from './encryptionService';
import { KeyVaultService } from './keyVaultService';
import { StorageService } from './storageService';
import config from '../config';
import { AuditService } from './auditService';
import type { Poll, PollOption, VoteTrustPolicy } from '../types/poll';
import { BoundedMap } from '../utils/boundedMap';

// Re-exported for backward compatibility — `src/types/poll.ts` is now the
// single source of truth for these types; import from there in new code.
export type { Poll, PollOption };

function getApiBase(): string {
  return config.relay.api;
}

function getGunRelayBase(): string {
  return config.relay.gun.replace(/\/gun$/, '');
}

const pollActiveListeners = new Map<string, any>();
const PENDING_INVITE_FINALIZATIONS_KEY = 'interpoll_pending_invite_finalizations';
const LOCAL_POLLS_META_KEY = 'interpoll-local-polls-v1';
const LOCAL_POLLS_TOMBSTONES_META_KEY = 'interpoll-local-polls-tombstones-v1';
const LOCAL_POLL_BACKUP_TTL_MS = 30 * 60 * 1000;

type PendingInviteFinalization = {
  pollId: string;
  code: string;
  reservationId: string;
};

type LocalPollBackupEntry = {
  poll: Poll;
  backedUpAt: number;
};

type LocalPollBackupMap = Record<string, LocalPollBackupEntry>;

const POLL_DEBUG_KEY = 'interpoll_poll_debug';
type PollDebugCategory = 'create' | 'writes' | 'index' | 'ui' | 'all';

function getPollDebugCategories(): Set<string> {
  try {
    if (typeof window === 'undefined') return new Set();
    const raw = window.localStorage.getItem(POLL_DEBUG_KEY);
    if (!raw) return new Set();
    const normalized = raw.trim().toLowerCase();
    if (normalized === 'true') return new Set(['all']);
    return new Set(
      normalized
        .split(',')
        .map((part) => part.trim())
        .filter(Boolean),
    );
  } catch {
    return new Set();
  }
}

function isPollDebugEnabled(category: PollDebugCategory): boolean {
  const categories = getPollDebugCategories();
  return categories.has('all') || categories.has(category);
}

function logPollDebug(category: PollDebugCategory, message: string, meta?: Record<string, unknown>) {
  if (!isPollDebugEnabled(category)) return;
  const prefix = `[PollCreateDebug:${category}]`;
  if (meta) {
    console.log(prefix, message, meta);
    return;
  }
  console.log(prefix, message);
}

// Search indexing is not a client concern. The gun-relay process indexes posts
// and polls off its own Gun write hook (gun-relay/gun-relay-enhanced.js,
// maybeIndexNode), so anything that reaches the graph is indexed regardless of
// whether the author was signed in. The old client-side POST to /api/index could
// never have worked: that endpoint requires a shared secret a browser cannot hold,
// so every call returned 401 into a swallowed warning — and it paid for a
// proof-of-work seal on the publish path to do it.

export class PollService {
  private static get gun() { return GunService.getGun(); }
  private static localPollBackupWriteQueue: Promise<void> = Promise.resolve();
  private static getPollPath(pollId: string) { return this.gun.get('polls').get(pollId); }

  /**
   * Ask the relay's DB mirror whether a poll actually reached it. Gun put acks
   * fire once local storage accepts the write and read-backs are served from
   * the local graph, so neither proves the relay holds the data — only an
   * independent read like this can. Returns true (relay has it), false
   * (endpoint reachable but poll absent after retries), or null when the
   * endpoint is unreachable/has no DB (inconclusive).
   */
  static async verifyRelayPersistence(pollId: string, deadlineMs = 8000): Promise<boolean | null> {
    // The relay DB stores polls at 'polls/<id>' (bare path).
    // Also check 'v3/polls/<id>' in case the namespace is stored explicitly.
    // Endpoint returns 200 if found, 404 if absent.
    const souls = [
      encodeURIComponent(`polls/${pollId}`),
      encodeURIComponent(`${GUN_NAMESPACE}/polls/${pollId}`),
    ];
    const base = getGunRelayBase();
    const deadline = Date.now() + deadlineMs;
    const retryDelayMs = 1500;
    let endpointReachable = false;

    for (;;) {
      const results = await Promise.all(souls.map(async soul => {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 3000);
        try {
          const res = await fetch(`${base}/db/soul?soul=${soul}`, { signal: controller.signal });
          if (res.ok) return 'found';       // 200 — relay has it
          if (res.status === 404) { endpointReachable = true; return 'absent'; }
          return 'unreachable';
        } catch {
          return 'unreachable';
        } finally {
          clearTimeout(timer);
        }
      }));

      if (results.includes('found')) return true;
      if (results.includes('absent')) endpointReachable = true;

      if (Date.now() + retryDelayMs > deadline) {
        return endpointReachable ? false : null;
      }
      await new Promise((resolve) => setTimeout(resolve, retryDelayMs));
    }
  }

  private static republishLoopStarted = false;
  private static republishInFlight = false;
  // Entries are removed only on success, so failures accumulated for the session.
  private static republishAttempts = new BoundedMap<string, number>({ maxSize: 500, ttlMs: 60 * 60_000 });
  private static readonly REPUBLISH_MAX_ATTEMPTS = 5;
  private static readonly REPUBLISH_INTERVAL_MS = 120_000;

  /** Gun-shaped shell + options map for (re)writing a poll — redacts encrypted polls exactly like createPoll. */
  private static toGunPollRecord(poll: Poll): { record: Record<string, unknown>; optionsMap: Record<string, any> } {
    const persistedOptions = poll.isEncrypted
      ? poll.options.map((option) => ({ ...option, text: '🔒 Encrypted option', voters: [] as string[] }))
      : poll.options;
    const optionsMap = this.buildOptionsMap(persistedOptions);
    return {
      optionsMap,
      record: {
        id: poll.id,
        communityId: poll.communityId,
        authorId: poll.authorId,
        authorName: poll.isEncrypted ? 'encrypted' : poll.authorName,
        authorShowRealName: poll.authorShowRealName || false,
        question: poll.isEncrypted ? '🔒 Encrypted Poll' : poll.question,
        description: poll.isEncrypted ? '' : (poll.description || ''),
        createdAt: poll.createdAt,
        expiresAt: poll.expiresAt,
        allowMultipleChoices: poll.allowMultipleChoices,
        showResultsBeforeVoting: poll.showResultsBeforeVoting,
        requireLogin: !!poll.requireLogin,
        isPrivate: !!poll.isPrivate,
        totalVotes: poll.totalVotes || 0,
        isExpired: !!poll.isExpired,
        options: optionsMap,
        isEncrypted: poll.isEncrypted ? true : undefined,
        encryptedContent: poll.encryptedContent,
        authTag: poll.authTag,
        authorPubkey: poll.authorPubkey,
        contentSignature: poll.contentSignature,
      },
    };
  }

  /**
   * Re-push recent locally-backed-up polls the relay does not confirm holding.
   * Gun never retro-syncs puts made while the relay connection was dead — and a
   * rate-limited relay can drop messages on an open socket — so without this a
   * poll created during an outage stays invisible to everyone else forever.
   */
  static async republishUnconfirmedPolls(): Promise<void> {
    if (this.republishInFlight || typeof window === 'undefined') return;
    this.republishInFlight = true;
    try {
      const [map, tombstones] = await Promise.all([
        this.readLocalPollMap(),
        this.readLocalPollTombstones(),
      ]);
      const now = Date.now();
      const candidates = Object.values(map).filter((entry) => {
        const poll = entry?.poll;
        if (!poll?.id || tombstones[poll.id]) return false;
        const ageMs = now - (Number.isFinite(entry.backedUpAt) ? entry.backedUpAt : poll.createdAt || 0);
        if (ageMs > LOCAL_POLL_BACKUP_TTL_MS) return false;
        return (this.republishAttempts.get(poll.id) || 0) < this.REPUBLISH_MAX_ATTEMPTS;
      });
      for (const entry of candidates) {
        const poll = entry.poll;
        const confirmed = await this.verifyRelayPersistence(poll.id, 4000);
        if (confirmed === true) {
          this.republishAttempts.delete(poll.id);
          continue;
        }
        if (confirmed === null) continue; // verification endpoint unreachable — retry next tick
        this.republishAttempts.set(poll.id, (this.republishAttempts.get(poll.id) || 0) + 1);
        const { record, optionsMap } = this.toGunPollRecord(poll);
        this.warmPollCache(record, optionsMap);
        await new Promise((resolve) => setTimeout(resolve, 3000));
        const recheck = await this.verifyRelayPersistence(poll.id, 8000);
        if (recheck === true) {
          this.republishAttempts.delete(poll.id);
          console.info(`[PollService] Republished poll ${poll.id} to relay after missed sync`);
        } else {
          logPollDebug('writes', 'Republish attempt did not confirm', {
            pollId: poll.id,
            attempt: this.republishAttempts.get(poll.id),
          });
        }
      }
    } catch (error) {
      logPollDebug('writes', 'Republish sweep failed', {
        error: error instanceof Error ? error.message : String(error),
      });
    } finally {
      this.republishInFlight = false;
    }
  }

  /** Start the background republish loop (idempotent). Also re-sweeps on Gun instance rebuilds. */
  static startRepublishLoop(): void {
    if (this.republishLoopStarted || typeof window === 'undefined') return;
    this.republishLoopStarted = true;
    GunService.onReconnect(() => { void this.republishUnconfirmedPolls(); });
    const tick = () => {
      void this.republishUnconfirmedPolls().finally(() => {
        setTimeout(tick, this.REPUBLISH_INTERVAL_MS);
      });
    };
    setTimeout(tick, 20_000);
  }
  private static getCommunityPollPath(communityId: string, pollId: string) {
    return this.gun.get('communities').get(communityId).get('polls').get(pollId);
  }

  private static enqueueLocalPollBackupWrite(task: () => Promise<void>): Promise<void> {
    const run = this.localPollBackupWriteQueue.then(task, task);
    this.localPollBackupWriteQueue = run.catch(() => {});
    return run;
  }

  private static sanitizeForGun<T>(value: T): T {
    if (Array.isArray(value)) {
      return value.map((item) => this.sanitizeForGun(item)) as T;
    }
    if (value && typeof value === 'object') {
      const out: Record<string, unknown> = {};
      Object.entries(value as Record<string, unknown>).forEach(([key, entry]) => {
        if (entry === undefined) return;
        const sanitized = this.sanitizeForGun(entry);
        // Gun cannot persist an empty-object child node: it emits "0 length key!"
        // and the enclosing put never receives an ACK. Drop empty-object values.
        if (
          sanitized !== null &&
          typeof sanitized === 'object' &&
          !Array.isArray(sanitized) &&
          Object.keys(sanitized as Record<string, unknown>).length === 0
        ) {
          return;
        }
        out[key] = sanitized;
      });
      return out as T;
    }
    return value;
  }

  private static async registerPollPolicyBestEffort(pollId: string, requireLogin: boolean): Promise<void> {
    const initialRegistered = await AuditService.registerPollPolicy(pollId, requireLogin);
    if (initialRegistered) return;

    console.warn(
      `[PollService] Poll policy registration failed for ${pollId}; continuing decentralized propagation`,
    );
    logPollDebug('create', 'Poll policy registration failed; continuing with Gun writes', {
      pollId,
      requireLogin,
    });

    void (async () => {
      const retryDelaysMs = [1500, 5000, 15000];
      for (let attempt = 0; attempt < retryDelaysMs.length; attempt += 1) {
        await new Promise((resolve) => setTimeout(resolve, retryDelaysMs[attempt]));
        const registered = await AuditService.registerPollPolicy(pollId, requireLogin);
        if (registered) {
          logPollDebug('create', 'Poll policy registration retry succeeded', {
            pollId,
            attempt: attempt + 1,
          });
          return;
        }
      }
      console.warn(
        `[PollService] Poll policy remained unavailable after retries for ${pollId}; poll stays decentralized and relay-enforced vote policy may be unavailable`,
      );
    })();
  }

  private static buildPollRecord(pollData: any, options: PollOption[]): Poll | null {
    if (!pollData?.id || options.length === 0) return null;
    const totalVotes = options.reduce((sum, opt) => sum + (opt.votes || 0), 0);

    // Normalise Gun-encoded metadata (same coercions as normalizeGunPost in postService)
    const rawTags = pollData.tags;
    const tags: string[] | undefined = rawTags
      ? (typeof rawTags === 'string'
          ? rawTags.split(',').map((t: string) => t.trim()).filter(Boolean)
          : Array.isArray(rawTags) ? rawTags : undefined)
      : undefined;

    return {
      id: pollData.id, communityId: pollData.communityId || '',
      authorId: pollData.authorId || '', authorName: pollData.authorName || 'Anonymous',
      question: pollData.question || '', description: pollData.description || '',
      options, createdAt: pollData.createdAt || Date.now(),
      expiresAt: pollData.expiresAt || 0,
      allowMultipleChoices: !!pollData.allowMultipleChoices,
      showResultsBeforeVoting: !!pollData.showResultsBeforeVoting,
      requireLogin: !!pollData.requireLogin, isPrivate: !!pollData.isPrivate,
      totalVotes, isExpired: Date.now() > (pollData.expiresAt || 0),
      upvotes: pollData.upvotes || 0,
      downvotes: pollData.downvotes || 0,
      score: (pollData.upvotes || 0) - (pollData.downvotes || 0),
      isEncrypted: pollData.isEncrypted || false,
      encryptedContent: pollData.encryptedContent || undefined,
      authTag: pollData.authTag || undefined,
      authorPubkey: pollData.authorPubkey || undefined,
      contentSignature: pollData.contentSignature || undefined,
      voteTrustPolicy: this.parseVoteTrustPolicy(pollData.voteTrustPolicy),
      // Moderation/categorisation metadata — written by backend after AI classification
      ...(pollData.category  ? { category:  String(pollData.category)  } : {}),
      ...(tags?.length       ? { tags }                                   : {}),
      ...(pollData.sentiment ? { sentiment: pollData.sentiment as Poll['sentiment'] } : {}),
      ...(pollData.nsfw      ? { nsfw: true }                             : {}),
    };
  }

  /** Parse the JSON-string-encoded Sybil-resistance policy stored on the Gun node. */
  private static parseVoteTrustPolicy(raw: unknown): VoteTrustPolicy | undefined {
    if (!raw) return undefined;
    let obj: any = raw;
    if (typeof raw === 'string') {
      try { obj = JSON.parse(raw); } catch { return undefined; }
    }
    const tiers = ['open', 'pow', 'relay', 'issuer'];
    const modes = ['separate', 'gate'];
    if (obj && tiers.includes(obj.requiredTier) && modes.includes(obj.mode)) {
      return { requiredTier: obj.requiredTier, mode: obj.mode };
    }
    return undefined;
  }

  private static isOffline(): boolean {
    if (typeof navigator === 'undefined') return true;
    return navigator.onLine === false;
  }

  private static async readLocalPollMap(): Promise<LocalPollBackupMap> {
    try {
      const raw = await StorageService.getMetadata(LOCAL_POLLS_META_KEY);
      if (!raw || typeof raw !== 'object') return {};
      const normalized: LocalPollBackupMap = {};
      Object.entries(raw as Record<string, any>).forEach(([pollId, value]) => {
        if (!value || typeof value !== 'object') return;
        if ('poll' in value && value.poll && typeof value.poll === 'object') {
          const poll = value.poll as Poll;
          if (!poll?.id || !Array.isArray(poll.options) || poll.options.length === 0) return;
          normalized[pollId] = {
            poll,
            backedUpAt: Number(value.backedUpAt) || poll.createdAt || Date.now(),
          };
          return;
        }
        const legacyPoll = value as Poll;
        if (!legacyPoll?.id || !Array.isArray(legacyPoll.options) || legacyPoll.options.length === 0) return;
        normalized[pollId] = {
          poll: legacyPoll,
          backedUpAt: legacyPoll.createdAt || Date.now(),
        };
      });
      return normalized;
    } catch {
      return {};
    }
  }

  private static async readLocalPollTombstones(): Promise<Record<string, number>> {
    try {
      const raw = await StorageService.getMetadata(LOCAL_POLLS_TOMBSTONES_META_KEY);
      if (!raw || typeof raw !== 'object') return {};
      const normalized: Record<string, number> = {};
      Object.entries(raw as Record<string, unknown>).forEach(([pollId, value]) => {
        const ts = Number(value);
        if (Number.isFinite(ts) && ts > 0) normalized[pollId] = ts;
      });
      return normalized;
    } catch {
      return {};
    }
  }

  private static normalizeLocalPoll(poll: Poll): Poll {
    const totalVotes = poll.options.reduce((sum, option) => sum + (option.votes || 0), 0);
    return {
      ...poll,
      totalVotes,
      isExpired: Date.now() > (poll.expiresAt || 0),
    };
  }

  private static localPollBackupSignature(poll: Poll): string {
    return JSON.stringify({
      id: poll.id,
      communityId: poll.communityId,
      question: poll.question,
      description: poll.description || '',
      totalVotes: poll.totalVotes || 0,
      expiresAt: poll.expiresAt || 0,
      isPrivate: Boolean(poll.isPrivate),
      isEncrypted: Boolean(poll.isEncrypted),
      options: poll.options.map((option) => ({
        id: option.id,
        text: option.text,
        votes: option.votes || 0,
        voters: [...option.voters].sort(),
      })),
    });
  }

  private static async saveLocalPollBackup(poll: Poll): Promise<void> {
    const normalizedPoll = this.normalizeLocalPoll(poll);
    const nextSignature = this.localPollBackupSignature(normalizedPoll);
    await this.enqueueLocalPollBackupWrite(async () => {
      try {
        const [next, tombstones] = await Promise.all([
          this.readLocalPollMap(),
          this.readLocalPollTombstones(),
        ]);
        delete tombstones[poll.id];
        const existing = next[poll.id];
        if (existing?.poll && this.localPollBackupSignature(existing.poll) === nextSignature) {
          return;
        }
        next[poll.id] = { poll: normalizedPoll, backedUpAt: Date.now() };
        const ordered = Object.values(next).sort((a, b) => {
          const left = Number.isFinite(a.backedUpAt) ? a.backedUpAt : a.poll.createdAt;
          const right = Number.isFinite(b.backedUpAt) ? b.backedUpAt : b.poll.createdAt;
          return right - left;
        }).slice(0, 500);
        const compact: LocalPollBackupMap = {};
        ordered.forEach((item) => { compact[item.poll.id] = item; });
        await StorageService.setMetadata(LOCAL_POLLS_META_KEY, compact);
        await StorageService.setMetadata(LOCAL_POLLS_TOMBSTONES_META_KEY, tombstones);
      } catch (error) {
        logPollDebug('create', 'Failed to persist local poll backup', {
          pollId: poll.id,
          error: error instanceof Error ? error.message : String(error),
        });
      }
    });
  }

  private static async removeLocalPollBackup(pollId: string): Promise<void> {
    await this.enqueueLocalPollBackupWrite(async () => {
      try {
        const [map, tombstones] = await Promise.all([
          this.readLocalPollMap(),
          this.readLocalPollTombstones(),
        ]);
        if (!map[pollId]) return;
        delete map[pollId];
        tombstones[pollId] = Date.now();
        const recentTombstones = Object.entries(tombstones)
          .sort(([, a], [, b]) => b - a)
          .slice(0, 1000)
          .reduce<Record<string, number>>((acc, [id, ts]) => {
            acc[id] = ts;
            return acc;
          }, {});
        await StorageService.setMetadata(LOCAL_POLLS_META_KEY, map);
        await StorageService.setMetadata(LOCAL_POLLS_TOMBSTONES_META_KEY, recentTombstones);
      } catch {
        // best-effort local cleanup
      }
    });
  }

  static async loadLocalPollsForCommunity(communityId: string): Promise<Poll[]> {
    if (!this.isOffline()) return [];
    const [map, tombstones] = await Promise.all([
      this.readLocalPollMap(),
      this.readLocalPollTombstones(),
    ]);
    const now = Date.now();
    return Object.values(map)
      .filter((entry) => {
        if (!entry?.poll?.id) return false;
        if (tombstones[entry.poll.id]) return false;
        const ageMs = now - (Number.isFinite(entry.backedUpAt) ? entry.backedUpAt : entry.poll.createdAt || 0);
        if (ageMs > LOCAL_POLL_BACKUP_TTL_MS) return false;
        const poll = entry.poll;
        return poll.communityId === communityId && Array.isArray(poll.options) && poll.options.length > 0;
      })
      .map((entry) => this.normalizeLocalPoll(entry.poll))
      .sort((a, b) => b.createdAt - a.createdAt);
  }

  // ── Reduced timeouts: 300ms first attempt, 1.5s fallback (was 500ms / 3.5s) ─
  private static onceNode<T = any>(node: any, timeoutMs = 300): Promise<T | null> {
    return new Promise((resolve) => {
      let settled = false;
      node.once((value: T | null) => {
        if (settled) return;
        settled = true;
        resolve(value ?? null);
      });
      setTimeout(() => {
        if (settled) return;
        settled = true;
        resolve(null);
      }, timeoutMs);
    });
  }

  private static async getLocalPollBackup(pollId: string): Promise<Poll | null> {
    if (!this.isOffline()) return null;
    const [map, tombstones] = await Promise.all([
      this.readLocalPollMap(),
      this.readLocalPollTombstones(),
    ]);
    if (tombstones[pollId]) return null;
    const entry = map[pollId];
    const poll = entry?.poll;
    if (!poll?.id || !Array.isArray(poll.options) || poll.options.length === 0) return null;
    const backedUpAt = Number.isFinite(entry.backedUpAt) ? entry.backedUpAt : poll.createdAt || 0;
    if (!backedUpAt || (Date.now() - backedUpAt) > LOCAL_POLL_BACKUP_TTL_MS) return null;
    return this.normalizeLocalPoll(poll);
  }

  private static waitForNode<T = any>(
    node: any,
    predicate: (value: T | null) => boolean,
    timeoutMs = 1500, // was 3500 — cut by more than half
  ): Promise<T | null> {
    return new Promise((resolve) => {
      let settled = false;
      // `node.on(cb)` returns the *chain*, and chain.off() detaches every
      // listener on that soul — including unrelated live feed subscriptions
      // sharing the same path. Gun binds `this` inside the handler to that one
      // listener, so `this.off()` detaches only ours.
      node.on(function (this: any, value: T | null) {
        // Detach as soon as we're done — either we just resolved, or the
        // timeout already fired and this is a late event.
        if (settled) { try { this?.off?.(); } catch { /* already detached */ } return; }
        if (!predicate(value)) return;
        settled = true;
        try { this?.off?.(); } catch { /* already detached */ }
        resolve(value ?? null);
      });
      setTimeout(() => {
        if (settled) return;
        settled = true;
        // The listener detaches itself on its next fire (see above); we can't
        // detach it from here without tearing down every listener on the soul.
        resolve(null);
      }, timeoutMs);
    });
  }

  private static parsePollOptions(optionsData: any): PollOption[] {
    if (!optionsData || typeof optionsData !== 'object') return [];
    const options: PollOption[] = [];
    Object.keys(optionsData).forEach(key => {
      if (key === '_') return;
      const opt = optionsData[key];
      if (opt && opt.id) {
        options.push({
          id: opt.id,
          text: opt.text || '',
          votes: opt.votes || 0,
          voters: this.parseVoters(opt.voters),
        });
      }
    });
    return options;
  }

  private static parseVoters(votersData: any): string[] {
    if (!votersData) return [];
    if (Array.isArray(votersData)) {
      return votersData.filter((voterId): voterId is string => typeof voterId === 'string');
    }
    if (typeof votersData !== 'object') return [];
    // New format: Gun-native set — { [voterId]: true }
    // This allows per-voter leaf writes instead of rewriting the full array.
    return Object.entries(votersData)
      .filter(([key]) => key !== '_' && key !== '#')
      .map(([key, value]) => {
        if (value === true || value === 1) return key;
        // Legacy compat: numeric-indexed { "0": "voter-id" }
        if (typeof value === 'string') return value;
        return null;
      })
      .filter((voterId): voterId is string => typeof voterId === 'string' && voterId.length > 0);
  }

  /**
   * Build a Gun-native voter set: { [voterId]: true }
   * This means adding a voter is a single leaf write (gun.get(optionId).get('voters').get(voterId).put(true))
   * rather than serialising and rewriting the entire voters array.
   */
  private static buildVotersSet(voters: string[]): Record<string, true> {
    return Object.fromEntries(voters.map(id => [id, true as const]));
  }

  private static buildOptionsMap(options: PollOption[]): Record<string, any> {
    return Object.fromEntries(options.map((option, index) => {
      // Gun-native set ({ [voterId]: true }) so future incremental voter writes
      // hit a single leaf instead of rewriting the whole voters collection.
      const votersSet = this.buildVotersSet(option.voters || []);
      const entry: Record<string, any> = {
        id: option.id,
        text: option.text,
        votes: option.votes || 0,
      };
      // Gun refuses to ACK/persist a node that contains an empty-object child
      // (emits "0 length key!" and the put callback never fires). Only include
      // the voters sub-node when it actually has entries.
      if (Object.keys(votersSet).length > 0) {
        entry.voters = votersSet;
      }
      return [index, entry];
    }));
  }

  // ── API poll fetch (metadata fallback only; vote totals are ignored) ─────────
  private static async loadPollFromAPI(pollId: string): Promise<{ pollData: any | null; options: PollOption[] }> {
    try {
      const res = await fetch(`${getApiBase()}/api/poll/${pollId}`, {
        headers: { 'Cache-Control': 'stale-while-revalidate=30' },
      });
      if (!res.ok) return { pollData: null, options: [] };
      const data = await res.json();
      if (!data?.id) return { pollData: null, options: [] };
      // Never trust API vote totals; they can lag and cause bounce-back regressions.
      // We only use API for poll shell metadata and option labels.
      const options: PollOption[] = (data.options || []).map((o: any) => ({
        id: o.id, text: o.text || '', votes: 0, voters: [],
      }));
      return { pollData: data, options };
    } catch (error) {
      console.warn('Poll API fetch failed:', error);
      return { pollData: null, options: [] };
    }
  }

  private static async loadPollFromGun(
    pollId: string,
    allowApiOptionFallback = true,
    allowLocalBackupFallback = true,
  ): Promise<Poll | null> {
    const pollNode    = this.getPollPath(pollId);
    const optionsNode = pollNode.get('options');

    // ── Parallel fetch: root data and options start at the same time ──────────
    // Previously these were sequential (root wait → options wait) adding up to
    // 300+1500+300+1500 = 3.6s worst-case per poll on a slow relay.
    // Now both fire simultaneously, cutting the wall-clock cost to max(root, options).
    const [pollData, optionsData] = await Promise.all([
      this.onceNode<any>(pollNode, 300)
        .then(d => d?.id ? d : this.waitForNode<any>(pollNode, (v) => !!v?.id, 1500)),
      this.onceNode<any>(optionsNode, 300)
        .then(d => this.parsePollOptions(d).length > 0
          ? d
          : this.waitForNode<any>(optionsNode, (v) => this.parsePollOptions(v).length > 0, 1500)),
    ]);

    if (!pollData?.id && allowLocalBackupFallback) {
      return this.getLocalPollBackup(pollId);
    }
    if (!pollData?.id) return null;

    let options = this.parsePollOptions(optionsData);

    // Inline shell fallback (embedded in root write as redundancy)
    if (options.length === 0) options = this.parsePollOptions(pollData?.options);

    // Community-scoped fallback if global options are still missing
    if (options.length === 0 && pollData.communityId) {
      options = await this.loadCommunityPollOptions(pollData.communityId, pollId);
    }

    // API metadata-only fallback as last resort
    if (options.length === 0 && allowApiOptionFallback) {
      const apiFallback = await this.loadPollFromAPI(pollId);
      options = apiFallback.options;
    }

    const builtPoll = this.buildPollRecord(pollData, options);
    if (builtPoll) {
      void this.saveLocalPollBackup(builtPoll);
      return builtPoll;
    }
    if (allowLocalBackupFallback) {
      return this.getLocalPollBackup(pollId);
    }
    return null;
  }

  private static async loadPollFromCommunityPath(
    communityId: string,
    pollId: string,
    allowApiOptionFallback = true,
    allowLocalBackupFallback = true,
  ): Promise<Poll | null> {
    if (!communityId) return null;
    const pollNode = this.getCommunityPollPath(communityId, pollId);
    let pollData = await this.onceNode<any>(pollNode, 300);
    if (!pollData?.id) {
      pollData = await this.waitForNode<any>(pollNode, (value) => !!value?.id, 1500);
    }
    if (!pollData?.id && allowLocalBackupFallback) {
      const localBackup = await this.getLocalPollBackup(pollId);
      if (localBackup?.communityId === communityId) {
        return localBackup;
      }
      return null;
    }
    if (!pollData?.id) return null;

    let options = await this.loadCommunityPollOptions(communityId, pollId);
    let optionsCameFromGun = options.length > 0;
    if (options.length === 0) {
      const rootOptions = await this.loadPollOptions(pollId, false, pollData);
      if (rootOptions.length > 0) {
        options = rootOptions;
        optionsCameFromGun = true;
      } else if (allowApiOptionFallback) {
        const apiFallback = await this.loadPollFromAPI(pollId);
        options = apiFallback.options;
      }
    }
    const builtPoll = this.buildPollRecord({
      ...pollData,
      communityId: pollData.communityId || communityId,
    }, options);
    if (builtPoll) {
      if (optionsCameFromGun) {
        this.warmPollCache({
          ...pollData,
          communityId: builtPoll.communityId,
        }, this.buildOptionsMap(builtPoll.options));
      }
      void this.saveLocalPollBackup(builtPoll);
      return builtPoll;
    }
    if (allowLocalBackupFallback) {
      const localBackup = await this.getLocalPollBackup(pollId);
      if (localBackup?.communityId === communityId) {
        return localBackup;
      }
    }
    return null;
  }

  private static warmPollCache(pollData: any, optionsData?: any) {
    if (!pollData?.id) return;
    const pollNode = this.getPollPath(pollData.id);
    pollNode.put(this.sanitizeForGun(pollData));
    if (optionsData && typeof optionsData === 'object') {
      pollNode.get('options').put(this.sanitizeForGun(optionsData));
    }
    if (pollData.communityId) {
      const communityNode = this.getCommunityPollPath(pollData.communityId, pollData.id);
      communityNode.put(this.sanitizeForGun(pollData));
      if (optionsData && typeof optionsData === 'object') {
        communityNode.get('options').put(this.sanitizeForGun(optionsData));
      }
    }
  }

  static subscribeToPollsInCommunity(
    communityId: string,
    onPoll: (poll: Poll) => void,
    onInitialLoadDone?: () => void
  ): () => void {
    const communityPollsNode = this.gun.get('communities').get(communityId).get('polls');
    const listenerKey = `${communityId}-polls-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const seenIds = new Set<string>();
    const deferredLivePolls = new Map<string, Poll>();
    const loading = new Map<string, Promise<Poll | null>>();
    const pendingHydrationIds = new Set<string>();
    let initialLoadDone = false;
    let snapshotHandled = false;
    let hydrating = true;
    let disposed = false;
    let subscription: any;
    let hardTimeoutFired = false;
    const subscriptionStartTime = Date.now();

    const checkLoadComplete = () => {
      if (initialLoadDone || disposed) return;
      initialLoadDone = true;
      if (onInitialLoadDone) onInitialLoadDone();
    };

    const loadPollById = (pollId: string): Promise<Poll | null> => {
      if (disposed || !pollId || pollId === '_' || (hydrating && seenIds.has(pollId))) return Promise.resolve(null);
      const inFlight = loading.get(pollId);
      if (inFlight) return inFlight;
      const task = this.loadPoll(pollId, communityId)
        .then((poll) => {
          if (poll && !poll.communityId) {
            return { ...poll, communityId };
          }
          return poll;
        })
        .finally(() => { loading.delete(pollId); });
      loading.set(pollId, task);
      return task;
    };

    const emitPoll = (poll: Poll | null) => {
      if (disposed || !poll) return;
      const createdAt = typeof poll.createdAt === 'number' ? poll.createdAt : 0;
      const isLiveDuringHydration = hydrating && createdAt > subscriptionStartTime;
      if (isLiveDuringHydration) {
        seenIds.add(poll.id);
        deferredLivePolls.set(poll.id, poll);
        return;
      }
      if (!seenIds.has(poll.id)) { seenIds.add(poll.id); onPoll(poll); return; }
      if (!hydrating) onPoll(poll);
    };

    const loadAndEmitById = (pollId: string): Promise<void> => {
      return loadPollById(pollId).then(poll => { emitPoll(poll); });
    };

    const finalizeHydration = () => {
      if (disposed || !hydrating) return;
      hydrating = false;
      checkLoadComplete();
      if (deferredLivePolls.size > 0) {
        Array.from(deferredLivePolls.values())
          .sort((a, b) => b.createdAt - a.createdAt)
          .forEach(p => onPoll(p));
        deferredLivePolls.clear();
      }
    };

    const flushHydrationIds = () => {
      return (async () => {
        const batchSize = 40;
        while (!disposed && !hardTimeoutFired) {
          const ids = Array.from(pendingHydrationIds);
          if (ids.length === 0) break;
          pendingHydrationIds.clear();
          for (let i = 0; i < ids.length; i += batchSize) {
            const batch = ids.slice(i, i + batchSize);
            await Promise.all(batch.map(pollId => loadAndEmitById(pollId)));
          }
        }
      })();
    };

    // ── Hydration timer: 3s (was 15s) ─────────────────────────────────────────
    const hydrationTimer = setTimeout(() => {
      if (disposed || snapshotHandled) return;
      snapshotHandled = true;
      flushHydrationIds().finally(() => { finalizeHydration(); });
    }, 3000);

    // ── Hard timeout: 8s (was 30s) ────────────────────────────────────────────
    const hardTimeout = setTimeout(() => {
      if (disposed || !hydrating) return;
      hardTimeoutFired = true;
      finalizeHydration();
    }, 8000);

    subscription = communityPollsNode.map().on((_: any, pollId: string) => {
      if (disposed || !pollId || pollId === '_') return;
      if (hydrating) { if (!seenIds.has(pollId)) pendingHydrationIds.add(pollId); return; }
      void loadAndEmitById(pollId);
    });
    pollActiveListeners.set(listenerKey, { subscription, timer: hydrationTimer, hardTimeout });

    communityPollsNode.once((allPolls) => {
      if (disposed || snapshotHandled) return;
      snapshotHandled = true;
      clearTimeout(hydrationTimer);
      const keys = allPolls ? Object.keys(allPolls).filter(k => k !== '_') : [];
      keys.forEach(pollId => pendingHydrationIds.add(pollId));
      flushHydrationIds().finally(() => { finalizeHydration(); });
    });

    return () => {
      disposed = true;
      clearTimeout(hydrationTimer);
      clearTimeout(hardTimeout);
      if (subscription) subscription.off();
      pollActiveListeners.delete(listenerKey);
    };
  }

  static subscribeToAllPolls(
    onPoll: (poll: Poll) => void,
    onInitialLoadDone?: () => void
  ): () => void {
    const pollsNode = this.gun.get('polls');
    const listenerKey = `all-polls-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const seenIds = new Set<string>();
    const deferredLivePolls = new Map<string, Poll>();
    const loading = new Map<string, Promise<Poll | null>>();
    const pendingHydrationIds = new Set<string>();
    let initialLoadDone = false;
    let snapshotHandled = false;
    let hydrating = true;
    let disposed = false;
    let subscription: any;
    let hardTimeoutFired = false;
    const subscriptionStartTime = Date.now();

    const checkLoadComplete = () => {
      if (initialLoadDone || disposed) return;
      initialLoadDone = true;
      if (onInitialLoadDone) onInitialLoadDone();
    };

    const loadPollById = (pollId: string): Promise<Poll | null> => {
      if (disposed || !pollId || pollId === '_' || (hydrating && seenIds.has(pollId))) return Promise.resolve(null);
      const inFlight = loading.get(pollId);
      if (inFlight) return inFlight;
      const task = this.loadPoll(pollId).finally(() => { loading.delete(pollId); });
      loading.set(pollId, task);
      return task;
    };

    const emitPoll = (poll: Poll | null) => {
      if (disposed || !poll) return;
      const createdAt = typeof poll.createdAt === 'number' ? poll.createdAt : 0;
      const isLiveDuringHydration = hydrating && createdAt > subscriptionStartTime;
      if (isLiveDuringHydration) { seenIds.add(poll.id); deferredLivePolls.set(poll.id, poll); return; }
      if (!seenIds.has(poll.id)) { seenIds.add(poll.id); onPoll(poll); return; }
      if (!hydrating) onPoll(poll);
    };

    const loadAndEmitById = (pollId: string): Promise<void> => {
      return loadPollById(pollId).then(poll => { emitPoll(poll); });
    };

    const finalizeHydration = () => {
      if (disposed || !hydrating) return;
      hydrating = false;
      checkLoadComplete();
      if (deferredLivePolls.size > 0) {
        Array.from(deferredLivePolls.values())
          .sort((a, b) => b.createdAt - a.createdAt)
          .forEach(p => onPoll(p));
        deferredLivePolls.clear();
      }
    };

    const flushHydrationIds = () => {
      return (async () => {
        const batchSize = 40;
        while (!disposed && !hardTimeoutFired) {
          const ids = Array.from(pendingHydrationIds);
          if (ids.length === 0) break;
          pendingHydrationIds.clear();
          for (let i = 0; i < ids.length; i += batchSize) {
            const batch = ids.slice(i, i + batchSize);
            await Promise.all(batch.map(pollId => loadAndEmitById(pollId)));
          }
        }
      })();
    };

    // ── Hydration timer: 3s (was 15s) ─────────────────────────────────────────
    const hydrationTimer = setTimeout(() => {
      if (disposed || snapshotHandled) return;
      snapshotHandled = true;
      flushHydrationIds().finally(() => { finalizeHydration(); });
    }, 3000);

    // ── Hard timeout: 8s (was 30s) ────────────────────────────────────────────
    const hardTimeout = setTimeout(() => {
      if (disposed || !hydrating) return;
      hardTimeoutFired = true;
      finalizeHydration();
    }, 8000);

    subscription = pollsNode.map().on((_: any, pollId: string) => {
      if (disposed || !pollId || pollId === '_') return;
      if (hydrating) { if (!seenIds.has(pollId)) pendingHydrationIds.add(pollId); return; }
      void loadAndEmitById(pollId);
    });
    pollActiveListeners.set(listenerKey, { subscription, timer: hydrationTimer, hardTimeout });

    pollsNode.once((allPolls) => {
      if (disposed || snapshotHandled) return;
      snapshotHandled = true;
      clearTimeout(hydrationTimer);
      const keys = allPolls ? Object.keys(allPolls).filter(k => k !== '_') : [];
      keys.forEach(pollId => pendingHydrationIds.add(pollId));
      flushHydrationIds().finally(() => { finalizeHydration(); });
    });

    return () => {
      disposed = true;
      clearTimeout(hydrationTimer);
      clearTimeout(hardTimeout);
      if (subscription) subscription.off();
      pollActiveListeners.delete(listenerKey);
    };
  }

  static async createPoll(data: {
    communityId: string;
    authorId: string;
    authorName: string;
    authorShowRealName?: boolean;
    question: string;
    description?: string;
    options: string[];
    durationDays: number;
    allowMultipleChoices: boolean;
    showResultsBeforeVoting: boolean;
    requireLogin: boolean;
    isPrivate: boolean;
    inviteCodeCount?: number;
    voteTrustPolicy?: VoteTrustPolicy;
  }, preGeneratedId?: string): Promise<Poll> {
    const createStartedAt = performance.now();
    logPollDebug('create', 'createPoll entered', {
      communityId: data.communityId,
      isPrivate: data.isPrivate,
      durationDays: data.durationDays,
      optionsCount: data.options.length,
      hasDescription: Boolean(data.description?.trim()),
      inviteCodeCount: data.inviteCodeCount,
    });
    const pollId   = preGeneratedId || `poll-${Date.now()}-${Math.random().toString(36).slice(2, 11)}`;
    const now      = Date.now();
    const expiresAt = now + data.durationDays * 86400000;

    const pollOptions: PollOption[] = data.options.map((text, idx) => ({
      id: `${pollId}-option-${idx}`, text, votes: 0, voters: [],
    }));

    const poll: Poll = {
      id: pollId, communityId: data.communityId, authorId: data.authorId,
      authorName: data.authorName, authorShowRealName: data.authorShowRealName || false,
      question: data.question, description: data.description || '', options: pollOptions,
      createdAt: now, expiresAt, allowMultipleChoices: data.allowMultipleChoices,
      showResultsBeforeVoting: data.showResultsBeforeVoting,
      requireLogin: !!data.requireLogin, isPrivate: !!data.isPrivate,
      totalVotes: 0, isExpired: false,
      voteTrustPolicy: data.voteTrustPolicy,
    };

    try {
      const { KeyService }    = await import('./keyService');
      const { CryptoService } = await import('./cryptoService');
      const keyPair    = await KeyService.getKeyPair();
      // Include the Sybil-resistance policy in the signed content hash so a peer
      // can't silently weaken it (e.g. downgrade to `open`) — NOTE: poll
      // signatures are not yet verified on read (see security-debt), so this
      // signs the policy but full tamper-evidence needs read-side verification.
      const contentHash = CryptoService.hash(JSON.stringify({ question: poll.question, communityId: poll.communityId, timestamp: poll.createdAt, voteTrustPolicy: poll.voteTrustPolicy || null }));
      const signature  = CryptoService.sign(contentHash, keyPair.privateKey);
      poll.authorPubkey      = keyPair.publicKey;
      poll.contentSignature  = signature;
      logPollDebug('create', 'Poll signing completed', { pollId });
    } catch (err) { console.warn('Failed to sign poll:', err); }

    if (poll.communityId) {
      const storedKey = await KeyVaultService.getKey(poll.communityId);
      if (storedKey) {
        try {
          const aesKey = await EncryptionService.importKey(storedKey.key);
          const encryptableData = { question: poll.question, description: poll.description, options: poll.options, authorName: poll.authorName };
          poll.encryptedContent = await EncryptionService.encrypt(JSON.stringify(encryptableData), aesKey);
          poll.authTag          = await EncryptionService.generateAuthTag(aesKey, poll.id, String(poll.createdAt), poll.authorId);
          poll.isEncrypted      = true;
          logPollDebug('create', 'Poll encryption completed', { pollId });
        } catch (err) {
          throw new Error(`Failed to encrypt poll: ${err instanceof Error ? err.message : String(err)}`);
        }
      } else {
        logPollDebug('create', 'No encryption key for community; proceeding unencrypted', { pollId, communityId: poll.communityId });
      }
    }

    const persistedPollOptions = poll.isEncrypted
      ? pollOptions.map((option) => ({ ...option, text: '🔒 Encrypted option', voters: [] as string[] }))
      : pollOptions;
    const optionsMap = this.buildOptionsMap(persistedPollOptions);
    const gunPoll = {
      id: poll.id,
      communityId: poll.communityId,
      authorId: poll.authorId,
      authorName: poll.isEncrypted ? 'encrypted' : poll.authorName,
      authorShowRealName: poll.authorShowRealName,
      question: poll.isEncrypted ? '🔒 Encrypted Poll' : poll.question,
      description: poll.isEncrypted ? '' : poll.description,
      createdAt: poll.createdAt,
      expiresAt: poll.expiresAt,
      allowMultipleChoices: poll.allowMultipleChoices,
      showResultsBeforeVoting: poll.showResultsBeforeVoting,
      requireLogin: poll.requireLogin,
      isPrivate: poll.isPrivate,
      totalVotes: 0,
      isExpired: false,
      options: optionsMap,
      isEncrypted: poll.isEncrypted ? true : undefined,
      encryptedContent: poll.encryptedContent,
      authTag: poll.authTag,
      authorPubkey: poll.authorPubkey,
      contentSignature: poll.contentSignature,
      voteTrustPolicy: poll.voteTrustPolicy ? JSON.stringify(poll.voteTrustPolicy) : undefined,
    };

    await this.registerPollPolicyBestEffort(poll.id, poll.requireLogin);

    const createWriteOptions = { timeoutMs: 15000 } as const;
    const optionWriteOptions = { timeoutMs: 8000, resolveOnTimeout: true } as const;
    let pollRootWriteTimedOut = false;
    await this.putPromise(this.getPollPath(pollId), gunPoll, {
      ...createWriteOptions,
      resolveOnTimeout: true,
      label: 'poll root write',
      onTimeout: () => { pollRootWriteTimedOut = true; },
    });
    await this.putPromise(this.getPollPath(pollId).get('options'), optionsMap, { ...optionWriteOptions, label: 'poll options write' });

    const communityPolls = this.gun.get('communities').get(data.communityId).get('polls');
    let communityRootWriteTimedOut = false;
    await this.putPromise(communityPolls.get(pollId), gunPoll, {
      ...createWriteOptions,
      resolveOnTimeout: true,
      label: 'community poll write',
      onTimeout: () => { communityRootWriteTimedOut = true; },
    });
    await this.putPromise(communityPolls.get(pollId).get('options'), optionsMap, { ...optionWriteOptions, label: 'community poll options write' });
    if (pollRootWriteTimedOut || communityRootWriteTimedOut) {
      logPollDebug('create', 'Root/community write timeout detected, verifying persisted poll', { pollId });

      // Fast path: read Gun's local in-memory graph (works fully offline).
      // resolveOnTimeout means the data IS in Gun's local outbox even without relay ack.
      const [rootLocal, communityLocal] = await Promise.all([
        this.onceNode<any>(this.getPollPath(pollId), 1000),
        this.onceNode<any>(communityPolls.get(pollId), 1000),
      ]);
      if (rootLocal?.id && communityLocal?.id) {
        logPollDebug('create', 'Local graph confirmed poll write (offline OK — will sync on reconnect)', { pollId });
        // Skip repair loop — fall through to return the poll
      } else {

      const createRepairDeadline = Date.now() + 45000;
      let [rootConfirmed, communityConfirmed] = await Promise.all([
        this.waitForNode<any>(this.getPollPath(pollId), (value) => Boolean(value?.id), 12000),
        this.waitForNode<any>(communityPolls.get(pollId), (value) => Boolean(value?.id), 12000),
      ]);

      if (!rootConfirmed?.id && communityConfirmed?.id) {
        logPollDebug('create', 'Community-only confirmation detected; retrying root write repair', { pollId });
      }
      for (let attempt = 1; !rootConfirmed?.id && attempt <= 3 && Date.now() < createRepairDeadline; attempt += 1) {
        const currentRoot = await this.onceNode<any>(this.getPollPath(pollId), 500);
        const rootRepairPayload = {
          ...gunPoll,
          totalVotes: typeof currentRoot?.totalVotes === 'number' ? currentRoot.totalVotes : gunPoll.totalVotes,
          isExpired: typeof currentRoot?.isExpired === 'boolean' ? currentRoot.isExpired : gunPoll.isExpired,
          options: currentRoot?.options && typeof currentRoot.options === 'object'
            ? currentRoot.options
            : gunPoll.options,
        };
        await this.putPromise(this.getPollPath(pollId), rootRepairPayload, {
          timeoutMs: 12000,
          resolveOnTimeout: true,
          label: `poll root repair write (attempt ${attempt})`,
        });
        rootConfirmed = await this.waitForNode<any>(this.getPollPath(pollId), (value) => Boolean(value?.id), 12000);
        if (!rootConfirmed?.id) {
          await new Promise((resolve) => setTimeout(resolve, 250));
        }
      }
      if (!rootConfirmed?.id) {
        throw new Error('Timed out waiting for poll root write ACK and root path could not be confirmed');
      }
      } // end else (relay confirmation path)
      if (!communityConfirmed?.id) {
        logPollDebug('create', 'Root-only confirmation detected; retrying community write repair', { pollId });
      }
      for (let attempt = 1; !communityConfirmed?.id && attempt <= 3 && Date.now() < createRepairDeadline; attempt += 1) {
        const currentCommunity = await this.onceNode<any>(communityPolls.get(pollId), 500);
        const communityRepairPayload = {
          ...gunPoll,
          totalVotes: typeof currentCommunity?.totalVotes === 'number' ? currentCommunity.totalVotes : gunPoll.totalVotes,
          isExpired: typeof currentCommunity?.isExpired === 'boolean' ? currentCommunity.isExpired : gunPoll.isExpired,
          options: currentCommunity?.options && typeof currentCommunity.options === 'object'
            ? currentCommunity.options
            : gunPoll.options,
        };
        await this.putPromise(communityPolls.get(pollId), communityRepairPayload, {
          timeoutMs: 12000,
          resolveOnTimeout: true,
          label: `community poll repair write (attempt ${attempt})`,
        });
        communityConfirmed = await this.waitForNode<any>(communityPolls.get(pollId), (value) => Boolean(value?.id), 12000);
        if (!communityConfirmed?.id) {
          await new Promise((resolve) => setTimeout(resolve, 250));
        }
      }
      if (!communityConfirmed?.id) {
        logPollDebug('create', 'Community path write timed out — poll exists at root, community will sync on reconnect', { pollId });
      }
      logPollDebug('create', 'Root write confirmed after timeout fallback', {
        pollId,
        rootConfirmed: Boolean(rootConfirmed?.id),
        communityConfirmed: Boolean(communityConfirmed?.id),
      });
    }

    if (poll.isPrivate) {
      const rawInviteCount = Number(data.inviteCodeCount);
      const safeInviteCount = Number.isFinite(rawInviteCount) ? rawInviteCount : 20;
      const inviteCount = Math.max(1, Math.min(200, Math.trunc(safeInviteCount)));
      const inviteCodes = this.generateInviteCodes(inviteCount);
      const codesMap: Record<string, any> = {};
      inviteCodes.forEach((code, i) => { codesMap[i] = { code, used: false }; });
      const inviteCodesWriteOptions = { ...createWriteOptions, resolveOnTimeout: true } as const;
      const countStoredInviteCodes = (value: any): number => {
        if (!value || typeof value !== 'object') return 0;
        return Object.entries(value).filter(([key, entry]) => (
          key !== '_' && Boolean(entry && typeof entry === 'object' && typeof (entry as Record<string, any>).code === 'string')
        )).length;
      };
      const inviteCodesListDeadline = Date.now() + 30000;
      let listConfirmed = false;
      for (let attempt = 1; attempt <= 3 && !listConfirmed && Date.now() < inviteCodesListDeadline; attempt += 1) {
        await Promise.all([
          this.putPromise(this.getPollPath(pollId).get('inviteCodes'), codesMap, { ...inviteCodesWriteOptions, label: `invite codes write (attempt ${attempt})` }),
          this.putPromise(communityPolls.get(pollId).get('inviteCodes'), codesMap, { ...inviteCodesWriteOptions, label: `community invite codes write (attempt ${attempt})` }),
        ]);
        const [rootList, communityList] = await Promise.all([
          this.onceNode<any>(this.getPollPath(pollId).get('inviteCodes'), 1200),
          this.onceNode<any>(communityPolls.get(pollId).get('inviteCodes'), 1200),
        ]);
        const rootCount = countStoredInviteCodes(rootList);
        const communityCount = countStoredInviteCodes(communityList);
        listConfirmed = rootCount >= inviteCodes.length && communityCount >= inviteCodes.length;
        if (!listConfirmed) {
          await new Promise((resolve) => setTimeout(resolve, 250));
        }
      }
      if (!listConfirmed) {
        logPollDebug('create', 'Invite code list write timed out — will sync on relay reconnect', { pollId });
      }
      const mainByCode      = this.getPollPath(pollId).get('inviteCodesByCode');
      const communityByCode = communityPolls.get(pollId).get('inviteCodesByCode');
      const byCodeWriteOptions = { timeoutMs: 4000, resolveOnTimeout: true } as const;
      const byCodeWriteDeadline = Date.now() + 45000;
      const byCodeChunkSize = 20;
      const normalizedCodes = inviteCodes.map((code) => code.trim().toUpperCase()).filter(Boolean);
      for (let start = 0; start < normalizedCodes.length; start += byCodeChunkSize) {
        let pendingCodes = normalizedCodes.slice(start, start + byCodeChunkSize);
        for (let attempt = 1; pendingCodes.length > 0 && attempt <= 3 && Date.now() < byCodeWriteDeadline; attempt += 1) {
          await Promise.all(
            pendingCodes.flatMap((codeKey) => ([
              this.putPromise(mainByCode.get(codeKey), { used: false }, { ...byCodeWriteOptions, label: `invite by-code write (${codeKey})` }),
              this.putPromise(communityByCode.get(codeKey), { used: false }, { ...byCodeWriteOptions, label: `community invite by-code write (${codeKey})` }),
            ])),
          );

          const checks = await Promise.all(
            pendingCodes.map(async (codeKey) => {
              const [mainEntry, communityEntry] = await Promise.all([
                this.onceNode<any>(mainByCode.get(codeKey), 800),
                this.onceNode<any>(communityByCode.get(codeKey), 800),
              ]);
              const mainOk = Boolean(mainEntry && typeof mainEntry === 'object');
              const communityOk = Boolean(communityEntry && typeof communityEntry === 'object');
              return { codeKey, ok: mainOk && communityOk };
            }),
          );
          pendingCodes = checks.filter((item) => !item.ok).map((item) => item.codeKey);
          if (pendingCodes.length > 0) {
            await new Promise((resolve) => setTimeout(resolve, 200));
          }
        }
        if (pendingCodes.length > 0) {
          logPollDebug('create', 'Invite by-code entries timed out', { pollId, pendingCodes: pendingCodes.length }); // non-fatal: will sync
        }
      }
      (poll as any).inviteCodes = inviteCodes;
      logPollDebug('create', 'Private invite codes generated', { pollId, inviteCount });
    }


    const relayConfirmed = await this.verifyRelayPersistence(pollId);
    poll.relayConfirmed = relayConfirmed === null
      ? GunService.getPeerStats().isConnected
      : relayConfirmed;
    if (!poll.relayConfirmed) {
      this.startRepublishLoop();
      setTimeout(() => { void this.republishUnconfirmedPolls(); }, 15_000);
    }

    logPollDebug('create', 'createPoll completed', {
      pollId,
      relayConfirmed: poll.relayConfirmed,
      durationMs: Math.round(performance.now() - createStartedAt),
    });
    await this.saveLocalPollBackup(poll);
    return poll;
  }

  // ── Canonical poll read: Gun/local only (never API vote ingestion) ───────────
  static async loadPoll(pollId: string, communityId?: string): Promise<Poll | null> {
    if (communityId) {
      const rootPoll = await this.loadPollFromGun(pollId, false, false);
      if (rootPoll) {
        return rootPoll.communityId ? rootPoll : { ...rootPoll, communityId };
      }
      const communityPoll = await this.loadPollFromCommunityPath(communityId, pollId, false, false);
      if (communityPoll) {
        return communityPoll;
      }
      const localBackup = await this.getLocalPollBackup(pollId);
      if (localBackup?.communityId === communityId) {
        return localBackup;
      }
      return null;
    }
    return this.loadPollFromGun(pollId, false);
  }

  // ── UX fallback read: Gun first, then metadata-only API shell ─────────────────
  static async loadPollWithApiFallback(pollId: string, communityId?: string): Promise<Poll | null> {
    if (communityId) {
      const gunPoll = await this.loadPollFromGun(pollId, false, false);
      if (gunPoll) {
        return gunPoll.communityId ? gunPoll : { ...gunPoll, communityId };
      }
      const communityPoll = await this.loadPollFromCommunityPath(communityId, pollId, false, false);
      if (communityPoll) {
        return communityPoll;
      }
      const localBackup = await this.getLocalPollBackup(pollId);
      if (localBackup?.communityId === communityId) {
        return localBackup;
      }
    } else {
      const gunPoll = await this.loadPollFromGun(pollId, true);
      if (gunPoll) {
        return gunPoll;
      }
    }
    const { pollData: apiData, options: apiOptions } = await this.loadPollFromAPI(pollId);
    return this.buildPollRecord(apiData, apiOptions);
  }

  /**
   * Read a poll's options by dereferencing each child node.
   *
   * When an options map is read cold from a relay, Gun returns the children as
   * unresolved `{'#': soul}` references rather than inlined objects, so a plain
   * `.once()` + `parsePollOptions()` sees no `id` on any child and drops every
   * option (making the whole poll invisible). `.map().once()` resolves each
   * child soul to its real `{ id, text, votes }` data.
   */
  private static readOptionsViaMap(optionsNode: any, timeoutMs = 1800): Promise<PollOption[]> {
    return new Promise((resolve) => {
      const collected = new Map<string, PollOption>();
      let settled = false;
      let subscription: any;
      const finish = () => {
        if (settled) return;
        settled = true;
        if (subscription?.off) subscription.off();
        const ordered = Array.from(collected.entries())
          .sort(([a], [b]) => {
            const na = Number(a); const nb = Number(b);
            if (Number.isFinite(na) && Number.isFinite(nb)) return na - nb;
            return a < b ? -1 : a > b ? 1 : 0;
          })
          .map(([, option]) => option);
        resolve(ordered);
      };
      subscription = optionsNode.map().once((child: any, key: string) => {
        if (settled || !child || key === '_' || !child.id) return;
        collected.set(String(key), {
          id: child.id,
          text: child.text || '',
          votes: child.votes || 0,
          voters: this.parseVoters(child.voters),
        });
      });
      setTimeout(finish, timeoutMs);
    });
  }

  static async loadPollOptions(pollId: string, allowApiFallback = true, parentPollData?: any): Promise<PollOption[]> {
    const optionsNode = this.getPollPath(pollId).get('options');
    const optionsData = await this.onceNode<any>(optionsNode, 300);
    const parsed      = this.parsePollOptions(optionsData);
    if (parsed.length > 0) return parsed;

    // Cold relay reads return child options as unresolved {'#': soul} refs;
    // dereference each child explicitly so the poll isn't dropped for "0 options".
    const mapped = await this.readOptionsViaMap(optionsNode, 1800);
    if (mapped.length > 0) return mapped;

    // Root poll writes now redundantly include an inline options map.
    // Use it only after giving the dedicated options child path time to hydrate.
    const inlineParsed = this.parsePollOptions(parentPollData?.options);
    if (inlineParsed.length > 0) return inlineParsed;

    // Last resort (read-only): use API option labels/ids only; keep vote totals at zero.
    // Never write these fallback options into Gun or they can clobber real counts.
    if (allowApiFallback) {
      const fallback = await this.loadPollFromAPI(pollId);
      if (fallback.options.length > 0) {
        return fallback.options;
      }
    }
    return [];
  }

  private static async loadCommunityPollOptions(communityId: string, pollId: string): Promise<PollOption[]> {
    if (!communityId) return [];
    const optionsNode = this.getCommunityPollPath(communityId, pollId).get('options');
    const optionsData = await this.onceNode<any>(optionsNode, 300);
    const parsed = this.parsePollOptions(optionsData);
    if (parsed.length > 0) return parsed;

    // Same cold-relay ref-resolution problem as loadPollOptions; deref children.
    return this.readOptionsViaMap(optionsNode, 1800);
  }

  static async vote(pollId: string, optionIds: string[], voterId: string, communityId?: string): Promise<void> {
    // ── Step 1: Local vote-index check (works offline, covers all transports) ──
    // This runs BEFORE any network calls. A match means the chain already has a
    // block for this (pollId, deviceId) pair — reject without contacting the relay.
    const alreadyVotedLocally = await StorageService.hasVoted(pollId, voterId).catch(() => false);
    if (alreadyVotedLocally) {
      throw new Error('Already voted: your device has a local record of voting on this poll.');
    }

    // Voting must use Gun-backed state to avoid API bounce-back or stale zero baselines.
    const poll = await this.loadPollFromGun(pollId, false, false)
      ?? (communityId ? await this.loadPollFromCommunityPath(communityId, pollId, false, false) : null);
    if (!poll) throw new Error('Poll not found');
    if (poll.isExpired) throw new Error('Poll has expired');

    const selectedOptions = poll.options.filter(opt => optionIds.includes(opt.id));
    if (selectedOptions.length === 0) throw new Error('No valid options selected');
    if (!poll.allowMultipleChoices && selectedOptions.length > 1) throw new Error('Multiple choices not allowed');

    // Only vote on options the voter hasn't already voted for (idempotent)
    // Note: this is the Gun-state check (Step 2 equivalent for Gun path).
    // The chain-level check above is the authoritative dedup gate.
    const newVoteOptions = selectedOptions.filter(opt => !opt.voters.includes(voterId));
    if (newVoteOptions.length === 0) return; // already voted — no-op

    const confirmedOptionIds = newVoteOptions.map(o => o.id);

    // ── Surgical per-leaf writes ────────────────────────────────────────────
    // Instead of rewriting the full options map on every vote (O(all voters)),
    // we write only the changed leaves:
    //   polls/{id}/options/{optionIndex}/voters/{voterId}  = true
    //   polls/{id}/options/{optionIndex}/votes             = newCount
    //   polls/{id}/totalVotes                             = newTotal
    //
    // Because each voter gets their own leaf, concurrent votes no longer
    // clobber each other — Gun's last-write-wins applies per-leaf, not per-option.
    // The totalVotes counter is still a shared counter (one writer at a time),
    // but it's only bumped AFTER the voter leaf is confirmed, so a lost update
    // at most under-counts by the number of concurrent votes — not erases them.

    const voteWriteOptions = { timeoutMs: 12000, resolveOnTimeout: true } as const;

    // Build a lookup: option.id → numeric index in the Gun options map
    const optionIndexById = new Map<string, string>();
    {
      // Re-read the raw options node to get the numeric keys Gun uses
      const rawOptions = await this.onceNode<any>(this.getPollPath(pollId).get('options'), 500);
      if (rawOptions && typeof rawOptions === 'object') {
        Object.keys(rawOptions).forEach(key => {
          if (key === '_') return;
          const opt = rawOptions[key];
          if (opt?.id) optionIndexById.set(opt.id, key);
        });
      }
    }

    // Parallel leaf writes for each selected option
    const leafWrites: Promise<void>[] = [];
    // Set when an option can't be addressed by leaf key and we must fall back
    // to rewriting the whole options map.
    let needsFullOptionsWrite = false;
    const updatedOptions = poll.options.map(option => {
      if (!confirmedOptionIds.includes(option.id)) return option;

      const optKey = optionIndexById.get(option.id);
      const newVotes = (option.votes || 0) + 1;

      if (optKey !== undefined) {
        // Write voter presence leaf — race-safe: multiple writers all set their own key
        const rootOptionNode = this.getPollPath(pollId).get('options').get(optKey);
        leafWrites.push(
          this.putPromise(rootOptionNode.get('voters').get(voterId), true as any, {
            ...voteWriteOptions, label: `vote root voter leaf (opt ${optKey})`,
          }),
        );
        // Update vote count — still a shared counter but much smaller payload
        leafWrites.push(
          this.putPromise(rootOptionNode.get('votes'), newVotes as any, {
            ...voteWriteOptions, label: `vote root count (opt ${optKey})`,
          }),
        );

        if (poll.communityId) {
          const commOptionNode = this.getCommunityPollPath(poll.communityId, pollId).get('options').get(optKey);
          leafWrites.push(
            this.putPromise(commOptionNode.get('voters').get(voterId), true as any, {
              ...voteWriteOptions, label: `vote community voter leaf (opt ${optKey})`,
            }),
          );
          leafWrites.push(
            this.putPromise(commOptionNode.get('votes'), newVotes as any, {
              ...voteWriteOptions, label: `vote community count (opt ${optKey})`,
            }),
          );
        }
      } else {
        // Fallback: this option has no addressable key in the live Gun options
        // map, so there is no leaf to write. Flag a full options-map rewrite
        // (the pre-perf behaviour) so the vote still persists.
        console.warn(`[PollService] option key not found for ${option.id}, falling back to full options write`);
        needsFullOptionsWrite = true;
        return { ...option, votes: newVotes, voters: [...option.voters, voterId] };
      }

      return { ...option, votes: newVotes, voters: [...option.voters, voterId] };
    });

    const totalVotes = updatedOptions.reduce((sum, opt) => sum + (opt.votes || 0), 0);

    // Whole-map rewrite fallback for options with no addressable leaf key.
    if (needsFullOptionsWrite) {
      const optionsMap = this.buildOptionsMap(updatedOptions);
      leafWrites.push(
        this.putPromise(this.getPollPath(pollId).get('options'), optionsMap, {
          ...voteWriteOptions, label: 'vote root options fallback write',
        }),
      );
      if (poll.communityId) {
        leafWrites.push(
          this.putPromise(this.getCommunityPollPath(poll.communityId, pollId).get('options'), optionsMap, {
            ...voteWriteOptions, label: 'vote community options fallback write',
          }),
        );
      }
    }

    // Fire all leaf writes in parallel
    await Promise.all(leafWrites);

    // Update totalVotes counter on root + community path
    const pollPatch = { totalVotes };
    await Promise.all([
      this.putPromise(this.getPollPath(pollId), pollPatch, { ...voteWriteOptions, label: 'vote root totalVotes' }),
      poll.communityId
        ? this.putPromise(this.getCommunityPollPath(poll.communityId, pollId), pollPatch, { ...voteWriteOptions, label: 'vote community totalVotes' })
        : Promise.resolve(),
    ]);

    // Confirm voter leaf is readable (lighter check than parsing entire options)
    const isVoterLeafPresent = async (path: any): Promise<boolean> => {
      const val = await this.onceNode<any>(path, 1500);
      return val === true;
    };

    const firstOptKey = confirmedOptionIds.length > 0 ? optionIndexById.get(confirmedOptionIds[0]) : undefined;
    if (firstOptKey !== undefined) {
      const voterLeafNode = this.getPollPath(pollId).get('options').get(firstOptKey).get('voters').get(voterId);
      const voteRetryDeadline = Date.now() + 20000;
      let confirmed = await isVoterLeafPresent(voterLeafNode);
      for (let attempt = 1; !confirmed && attempt <= 3 && Date.now() < voteRetryDeadline; attempt += 1) {
        await this.putPromise(voterLeafNode, true as any, { ...voteWriteOptions, label: `voter leaf retry (attempt ${attempt})` });
        confirmed = await isVoterLeafPresent(voterLeafNode);
        if (!confirmed) await new Promise(r => setTimeout(r, 250));
      }
      if (!confirmed) {
        // Vote went to Gun's local outbox (resolveOnTimeout was true on write).
        // The leaf will sync to the relay when reconnected — treat as locally OK.
        logPollDebug('vote', 'Voter leaf not readable after retries — treating as locally committed (offline)', { pollId, voterId });
      }
    }

    await this.saveLocalPollBackup({
      ...poll,
      options: updatedOptions,
      totalVotes,
      isExpired: Date.now() > (poll.expiresAt || 0),
    });
  }

  static async voteOnPoll(pollId: string, optionIds: string[], voterId: string, communityId?: string): Promise<void> {
    return this.vote(pollId, optionIds, voterId, communityId);
  }

  /**
   * Content-level upvote/downvote on the poll itself (independent of option voting).
   * Mirrors PostService.voteOnPost's toggle semantics.
   *
   * `knownCounts` is supplied by the store (from pollsMap) so we never need to
   * load the poll from Gun — the poll may not be in the local graph if it was
   * loaded via the relay REST feed (radisk/localStorage disabled).
   */
  static async voteOnPollContent(
    pollId: string,
    direction: 'up' | 'down',
    userId: string,
    communityId?: string,
    knownCounts?: { upvotes: number; downvotes: number; previous: 'up' | 'down' | null },
  ): Promise<{ upvotes: number; downvotes: number; score: number }> {
    const gun = this.gun;

    // knownCounts is the pre-optimistic snapshot from the store — delta not yet
    // applied here, we apply it below exactly once.
    let upvotes: number;
    let downvotes: number;
    let existingDirection: 'up' | 'down' | null;

    if (knownCounts) {
      upvotes           = knownCounts.upvotes;
      downvotes         = knownCounts.downvotes;
      existingDirection = knownCounts.previous;
    } else {
      const poll = await this.loadPollFromGun(pollId, false, false)
        ?? (communityId ? await this.loadPollFromCommunityPath(communityId, pollId, false, false) : null);
      if (!poll) throw new Error('Poll not found');
      upvotes   = poll.upvotes   || 0;
      downvotes = poll.downvotes || 0;
      const voteKey = `vote_${userId}_poll_${pollId}`;
      const existingVote = await this.onceNode<any>(gun.get('votes').get(voteKey), 2000);
      existingDirection = existingVote?.type === 'up' ? 'up' : existingVote?.type === 'down' ? 'down' : null;
    }

    const togglingOff = existingDirection === direction;

    // Remove previous contribution, then apply new direction
    if (existingDirection === 'up')   upvotes   = Math.max(0, upvotes   - 1);
    if (existingDirection === 'down') downvotes = Math.max(0, downvotes - 1);
    if (!togglingOff) {
      if (direction === 'up') upvotes += 1; else downvotes += 1;
    }

    // ── Write vote via HTTP POST (fast) + Gun (peer sync fallback) ──────────
    const voteRecord = { userId, pollId, postId: pollId, at: Date.now(), type: togglingOff ? 'none' : direction };
    // HTTP write — direct to MySQL via relay, <100ms
    void fetch(`${(await import('../config')).default.relay.api}/api/content-vote`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(voteRecord),
    }).catch(() => {});
    // Gun write — parallel, for peer sync
    void new Promise<void>((resolve) => {
      gun.get('postVotes').get(pollId).get(userId).put(
        this.sanitizeForGun(voteRecord), () => resolve(),
      );
      setTimeout(resolve, 3_000);
    }).catch(() => {});

    const score = upvotes - downvotes;
    const patch = { upvotes, downvotes, score };

    // Write tally hints fire-and-forget
    void new Promise<void>((resolve) => {
      this.getPollPath(pollId).put(this.sanitizeForGun(patch), () => resolve());
      setTimeout(resolve, 3_000);
    }).catch(() => {});
    if (communityId) {
      void new Promise<void>((resolve) => {
        this.getCommunityPollPath(communityId, pollId).put(this.sanitizeForGun(patch), () => resolve());
        setTimeout(resolve, 3_000);
      }).catch(() => {});
    }

    return patch;
  }

  static async getInviteCodes(pollId: string): Promise<{ code: string; used: boolean }[]> {
    const codesNode = this.getPollPath(pollId).get('inviteCodes');
    const data      = await this.onceNode<any>(codesNode, 2000);
    if (!data) return [];
    const now = Date.now();
    return Object.keys(data)
      .filter(k => k !== '_')
      .map(k => ({ code: data[k].code, used: Boolean(data[k].used || (data[k].reservedUntil && Number(data[k].reservedUntil) > now)) }))
      .filter(c => c.code);
  }

  static async validateInviteCode(pollId: string, rawCode: string): Promise<void> {
    const code = rawCode.trim().toUpperCase();
    if (!code) throw new Error('Invite code is required');

    const byCodeNode = this.getPollPath(pollId).get('inviteCodesByCode').get(encodeURIComponent(code));
    const codeState = await this.onceNode<any>(byCodeNode, 1500);
    if (!codeState) throw new Error('Invalid invite code');
    if (codeState.used) throw new Error('Invite code already used');
    if (codeState.reservedUntil && Number(codeState.reservedUntil) > Date.now()) {
      throw new Error('Invite code is currently reserved by another voter');
    }
  }

  static async consumeInviteCode(pollId: string, rawCode: string): Promise<string> {
    const code = rawCode.trim().toUpperCase();
    if (!code) throw new Error('Invite code is required');

    const poll = await this.loadPoll(pollId);
    if (!poll) throw new Error('Poll not found');

    const codeKey = encodeURIComponent(code);
    const byCodeNode = this.getPollPath(pollId).get('inviteCodesByCode').get(codeKey);
    const communityByCodeNode = poll.communityId
      ? this.getCommunityPollPath(poll.communityId, pollId).get('inviteCodesByCode').get(codeKey)
      : null;

    const inviteCodes = await this.getInviteCodes(pollId);
    const matchingIndex = inviteCodes.findIndex((entry) => entry.code.trim().toUpperCase() === code);
    if (matchingIndex === -1) throw new Error('Invalid invite code');

    const currentState = await this.onceNode<any>(byCodeNode, 1500);
    if (!currentState) throw new Error('Invalid invite code');
    if (currentState.used) throw new Error('Invite code already used');
    if (currentState.reservedUntil && Number(currentState.reservedUntil) > Date.now()) {
      throw new Error('Invite code is currently reserved by another voter');
    }

    const reservationId = `invite-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    const reservedUntil = Date.now() + 30000;
    const listEntry = { code, used: false, reservedUntil };
    const mainCodesNode = this.getPollPath(pollId).get('inviteCodes').get(String(matchingIndex));
    const updates: Promise<void>[] = [
      this.putPromise(byCodeNode, { code, used: false, reservedBy: reservationId, reservedUntil }),
      this.putPromise(mainCodesNode, listEntry),
    ];

    if (communityByCodeNode && poll.communityId) {
      updates.push(this.putPromise(communityByCodeNode, { code, used: false, reservedBy: reservationId, reservedUntil }));
      updates.push(
        this.putPromise(
          this.getCommunityPollPath(poll.communityId, pollId).get('inviteCodes').get(String(matchingIndex)),
          listEntry,
        ),
      );
    }

    await Promise.all(updates);
    const confirmedState = await this.onceNode<any>(byCodeNode, 1500);
    if (confirmedState?.used || confirmedState?.reservedBy !== reservationId) {
      throw new Error('Invite code was claimed by another voter');
    }
    return reservationId;
  }

  static async finalizeInviteCode(pollId: string, rawCode: string, reservationId: string): Promise<void> {
    const code = rawCode.trim().toUpperCase();
    if (!code || !reservationId) return;

    const poll = await this.loadPoll(pollId);
    if (!poll) return;

    const codeKey = encodeURIComponent(code);
    const byCodeNode = this.getPollPath(pollId).get('inviteCodesByCode').get(codeKey);
    const communityByCodeNode = poll.communityId
      ? this.getCommunityPollPath(poll.communityId, pollId).get('inviteCodesByCode').get(codeKey)
      : null;

    const currentState = await this.onceNode<any>(byCodeNode, 1500);
    if (!currentState) return;
    if (currentState.used) return;
    if (currentState.reservedBy !== reservationId) {
      throw new Error('Invite code reservation no longer belongs to this vote');
    }

    const inviteCodes = await this.getInviteCodes(pollId);
    const matchingIndex = inviteCodes.findIndex((entry) => entry.code.trim().toUpperCase() === code);
    if (matchingIndex === -1) return;

    const listEntry = { code, used: true, reservedUntil: null };
    const updates: Promise<void>[] = [
      this.putPromise(byCodeNode, { code, used: true, usedAt: Date.now(), reservedBy: null, reservedUntil: null }),
      this.putPromise(this.getPollPath(pollId).get('inviteCodes').get(String(matchingIndex)), listEntry),
    ];

    if (communityByCodeNode && poll.communityId) {
      updates.push(this.putPromise(communityByCodeNode, { code, used: true, usedAt: Date.now(), reservedBy: null, reservedUntil: null }));
      updates.push(
        this.putPromise(
          this.getCommunityPollPath(poll.communityId, pollId).get('inviteCodes').get(String(matchingIndex)),
          listEntry,
        ),
      );
    }

    await Promise.all(updates);
  }

  private static loadPendingInviteFinalizations(): PendingInviteFinalization[] {
    try {
      const raw = localStorage.getItem(PENDING_INVITE_FINALIZATIONS_KEY);
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) return [];
      return parsed.filter((entry): entry is PendingInviteFinalization => (
        entry &&
        typeof entry.pollId === 'string' &&
        typeof entry.code === 'string' &&
        typeof entry.reservationId === 'string'
      ));
    } catch {
      return [];
    }
  }

  private static savePendingInviteFinalizations(entries: PendingInviteFinalization[]): void {
    if (entries.length === 0) {
      localStorage.removeItem(PENDING_INVITE_FINALIZATIONS_KEY);
      return;
    }
    localStorage.setItem(PENDING_INVITE_FINALIZATIONS_KEY, JSON.stringify(entries));
  }

  static queueInviteCodeFinalization(pollId: string, rawCode: string, reservationId: string): void {
    const code = rawCode.trim().toUpperCase();
    if (!pollId || !code || !reservationId) return;

    const pending = this.loadPendingInviteFinalizations();
    if (pending.some((entry) => (
      entry.pollId === pollId &&
      entry.code === code &&
      entry.reservationId === reservationId
    ))) {
      return;
    }

    pending.push({ pollId, code, reservationId });
    this.savePendingInviteFinalizations(pending);
  }

  static async flushPendingInviteCodeFinalizations(): Promise<void> {
    const pending = this.loadPendingInviteFinalizations();
    if (pending.length === 0) return;

    const remaining: PendingInviteFinalization[] = [];

    for (const entry of pending) {
      try {
        await this.finalizeInviteCode(entry.pollId, entry.code, entry.reservationId);
      } catch (error) {
        console.warn('Failed to finalize queued invite code reservation:', error);
        remaining.push(entry);
      }
    }

    this.savePendingInviteFinalizations(remaining);
  }

  static async releaseInviteCode(pollId: string, rawCode: string, reservationId?: string): Promise<void> {
    const code = rawCode.trim().toUpperCase();
    if (!code) return;

    const poll = await this.loadPoll(pollId);
    if (!poll) return;

    const codeKey = encodeURIComponent(code);
    const byCodeNode = this.getPollPath(pollId).get('inviteCodesByCode').get(codeKey);
    const communityByCodeNode = poll.communityId
      ? this.getCommunityPollPath(poll.communityId, pollId).get('inviteCodesByCode').get(codeKey)
      : null;

    const currentState = await this.onceNode<any>(byCodeNode, 1500);
    if (!currentState || currentState.used) return;
    if (reservationId && currentState.reservedBy && currentState.reservedBy !== reservationId) return;

    const inviteCodes = await this.getInviteCodes(pollId);
    const matchingIndex = inviteCodes.findIndex((entry) => entry.code.trim().toUpperCase() === code);
    if (matchingIndex === -1) return;

    const listEntry = { code, used: false, reservedUntil: null };
    const updates: Promise<void>[] = [
      this.putPromise(byCodeNode, { code, used: false, reservedBy: null, reservedUntil: null }),
      this.putPromise(this.getPollPath(pollId).get('inviteCodes').get(String(matchingIndex)), listEntry),
    ];

    if (communityByCodeNode && poll.communityId) {
      updates.push(this.putPromise(communityByCodeNode, { code, used: false, reservedBy: null, reservedUntil: null }));
      updates.push(
        this.putPromise(
          this.getCommunityPollPath(poll.communityId, pollId).get('inviteCodes').get(String(matchingIndex)),
          listEntry,
        ),
      );
    }

    await Promise.all(updates);
  }

  static async deletePoll(pollId: string, communityId: string): Promise<void> {
    await this.putPromise(this.getPollPath(pollId), null);
    await this.putPromise(this.getCommunityPollPath(communityId, pollId), null);
    await this.removeLocalPollBackup(pollId);
  }

  private static generateInviteCodes(count: number): string[] {
    const codes: string[] = [];
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    for (let i = 0; i < count; i++) {
      let code = '';
      for (let j = 0; j < 8; j++) code += chars[Math.floor(Math.random() * chars.length)];
      codes.push(code);
    }
    return codes;
  }

  private static putPromise(
    node: any,
    data: any,
    options: { timeoutMs?: number; resolveOnTimeout?: boolean; label?: string; onTimeout?: () => void } = {},
  ): Promise<void> {
    return new Promise((resolve, reject) => {
      const timeoutMs = options.timeoutMs ?? 8000;
      const resolveOnTimeout = options.resolveOnTimeout === true;
      const label = options.label || 'Gun write';
      const startedAt = performance.now();
      logPollDebug('writes', 'Write started', { label, timeoutMs });
      let settled = false;
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        const timeoutError = new Error(`Timed out waiting for ${label} ACK`);
        options.onTimeout?.();
        logPollDebug('writes', 'Write timeout', {
          label,
          timeoutMs,
          resolveOnTimeout,
          durationMs: Math.round(performance.now() - startedAt),
        });
        if (resolveOnTimeout) {
          resolve();
          return;
        }
        reject(timeoutError);
      }, timeoutMs);
      node.put(this.sanitizeForGun(data), (ack: any) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        if (ack?.err) {
          logPollDebug('writes', 'Write ack error', {
            label,
            error: ack.err,
            durationMs: Math.round(performance.now() - startedAt),
          });
          reject(new Error(ack.err));
        } else {
          logPollDebug('writes', 'Write ack success', {
            label,
            durationMs: Math.round(performance.now() - startedAt),
          });
          resolve();
        }
      });
    });
  }

  static unsubscribeAll(): void {
    pollActiveListeners.forEach(({ subscription, timer, hardTimeout }) => {
      clearTimeout(timer);
      clearTimeout(hardTimeout);
      if (subscription) subscription.off();
    });
    pollActiveListeners.clear();
  }

  static async decryptPoll(poll: Poll): Promise<Poll> {
    if (!poll.isEncrypted || !poll.encryptedContent) return poll;
    const storedKey = await KeyVaultService.getKey(poll.communityId);
    if (!storedKey) return poll;
    try {
      const aesKey   = await EncryptionService.importKey(storedKey.key);
      if (poll.authTag) {
        const valid = await EncryptionService.verifyAuthTag(aesKey, poll.authTag, poll.id, String(poll.createdAt), poll.authorId);
        if (!valid) return poll;
      }
      const decrypted = JSON.parse(await EncryptionService.decrypt(poll.encryptedContent, aesKey));
      return {
        ...poll,
        question:    decrypted.question    || poll.question,
        description: decrypted.description || poll.description,
        options:     decrypted.options     || poll.options,
        authorName:  decrypted.authorName  || poll.authorName,
      };
    } catch { return poll; }
  }
}