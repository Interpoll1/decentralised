import { schnorr } from '@noble/curves/secp256k1.js';
import { sha256 } from '@noble/hashes/sha2.js';
import { bytesToHex, hexToBytes } from '@noble/hashes/utils.js';
import { randomBytes } from 'crypto';
import { canonicalJSON } from './integrity.js';

export function verifySignature(message) {
  if (!message || typeof message !== 'object') return false;
  if (!message._pub || !message._sig) return false;
  if (typeof message._pub !== 'string' || typeof message._sig !== 'string') return false;

  try {
    if (!/^[0-9a-f]{64}$/i.test(message._pub)) return false;
    if (!/^[0-9a-f]{128}$/i.test(message._sig)) return false;

    const dataToVerify = canonicalJSON(message);
    const messageHash = bytesToHex(sha256(new TextEncoder().encode(dataToVerify)));
    return schnorr.verify(
      hexToBytes(message._sig),
      hexToBytes(messageHash),
      hexToBytes(message._pub)
    );
  } catch {
    return false;
  }
}

export function generateKeyPair() {
  const privateKeyBytes = randomBytes(32);
  const privateKey = bytesToHex(new Uint8Array(privateKeyBytes));
  const publicKey = bytesToHex(schnorr.getPublicKey(hexToBytes(privateKey)));

  return {
    publicKey,
    privateKey,
  };
}

export function signMessage(message, keyPair) {
  const dataToSign = canonicalJSON(message);
  const messageHash = bytesToHex(sha256(new TextEncoder().encode(dataToSign)));
  const sig = schnorr.sign(hexToBytes(messageHash), hexToBytes(keyPair.privateKey));
  return {
    ...message,
    _pub: keyPair.publicKey,
    _sig: bytesToHex(sig),
  };
}
