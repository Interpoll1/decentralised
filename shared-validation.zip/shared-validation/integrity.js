import crypto from 'crypto';

const META_FIELDS = new Set(['_hash', '_sig', '_pub', '_pow', '_ts', '_nonce']);

function stableStringify(val) {
  if (val === undefined) return undefined;
  if (val === null) return 'null';
  if (typeof val !== 'object') return JSON.stringify(val);
  if (Array.isArray(val)) {
    return '[' + val.map(v => stableStringify(v) ?? 'null').join(',') + ']';
  }
  const keys = Object.keys(val).sort();
  const pairs = [];
  for (const k of keys) {
    const sv = stableStringify(val[k]);
    if (sv !== undefined) pairs.push(JSON.stringify(k) + ':' + sv);
  }
  return '{' + pairs.join(',') + '}';
}

export function canonicalJSON(obj) {
  const stripped = {};
  for (const [k, v] of Object.entries(obj)) {
    if (!META_FIELDS.has(k)) stripped[k] = v;
  }
  return stableStringify(stripped);
}

export function computeHash(obj) {
  const canonical = canonicalJSON(obj);
  return crypto.createHash('sha256').update(canonical).digest('hex');
}

export function verifyContentHash(message) {
  if (!message || typeof message !== 'object') return false;
  if (!message._hash || typeof message._hash !== 'string') return false;
  if (!/^[0-9a-f]{64}$/.test(message._hash)) return false;
  try {
    const expected = computeHash(message);
    return crypto.timingSafeEqual(
      Buffer.from(expected, 'hex'),
      Buffer.from(message._hash, 'hex')
    );
  } catch {
    return false;
  }
}

export { META_FIELDS };
